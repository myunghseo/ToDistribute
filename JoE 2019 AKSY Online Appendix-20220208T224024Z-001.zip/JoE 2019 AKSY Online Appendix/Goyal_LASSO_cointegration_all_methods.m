%% Initialisation
clc; 
clear;
warning('off','all')

tic;

load Goyal_data_2012

y=premium(218:end);                     % dependent variable - equity premium
ylag=premium(218-1:end-1);

%x1=[dp dy];
x1=[dp dy ep bm ntis tbl tms dfy dfr];  % persistent explanatory variables
x2=[svar infl ltr];                     % stationary explanatory variables
x=[x1(218-1:end-1,:) x2(218-1:end-1,:)];
nx2=size(x2,2);


%% parameter setting
[nosample,nvar]=size(x);                % # of observations and explanatory variables for the entire dataset
m=240;                                  % window size
h=floor(0.1*m);                         % evaluation window size for forward chaining LASSO

% create storage variables
beta0=zeros(nosample-m,nvar+1);         % OLS estimates
betaC=zeros(nosample-m,1);              % constant only model
betaA=zeros(nosample-m,2);              % AR(1) model

betaF=zeros(nosample-m,nvar+1);         % LASSO_fwd estimates
beta1=zeros(nosample-m,nvar+1);         % LASSO_1 estimates
beta2=zeros(nosample-m,nvar+1);         % LASSO_2 estimates
betaE=zeros(nosample-m,nvar+1);         % elastic-net estimates

cvlambda1=zeros(1,nosample-m);
cvlambda2=zeros(1,nosample-m);

fe0=[];     % OLS kitchen sink
feC=[];     % constant only
feA=[];     % AR(1) model
feR=[];     % random walk

feM=[];     % forecast combination
feF=[];     % LASSO_{forward chaining}
fe1=[];     % LASSO_min
fe2=[];     % LASSO_fix
feE=[];     % elastic-net


%% start the loop of rolling window
for n=m:(nosample-1)
    
    % estimation using rolling window
    ys=y(n-m+1:n);
    xs=[ones(m,1) x(n-m+1:n,:)];
    yslag=ylag(n-m+1:n);
    
    %% ----------- Simple Models ----------- %%
    % OLS regression -- kitchen sink model
    [beta_hat0,~,~,~,stat0] =regress(ys, xs);
    fetemp0=y(n+1)-[1 x(n+1,:)]*beta_hat0;
    fe0=[fe0;fetemp0];
    beta0(n-m+1,:)=beta_hat0;
    
    % Constant only -- historical average
    [alfa,~,~,~,statC]=regress(ys,ones(m,1));
    fetempC=y(n+1)-alfa;
    feC=[feC;fetempC];
    betaC(n-m+1,:)=alfa;
    
    % AR(1) model
    [rho,~,~,~,statA]=regress(ys,[ones(m,1) yslag]);
    fetempA=y(n+1)-[1 ys(end)]*rho;
    feA=[feA; fetempA];
    betaA(n-m+1,:)=rho;
    
    % random walk model
    fetempR=y(n+1)-y(n);
    feR=[feR;fetempR];
        
    
    %% --------- forecast combination --------- %%
    ftempM=zeros(size(xs,2)-1,1);
    for i=2:size(xs,2)
        btempM=regress(ys,xs(:,[1 i]));
        ftempM(i-1)=[1 x(n+1,i-1)]*btempM;
    end
    fetempM=y(n+1)-mean(ftempM);
    feM=[feM; fetempM];
    
    
    %% ----------- Homo L1 Penalty ----------- %%
    % forward chaining LASSO
    [bF,FF] = lasso(xs(1:m-h,2:end),ys(1:m-h),'NumLambda',100);
    nlam=length(FF.Intercept);
    err=repmat(ys(m-h+1:m),1,nlam)-repmat(FF.Intercept,h,1)-xs(m-h+1:m,2:end)*bF;
    % find lambda that minimizes the forecast error
    [~,lamid]=min(sum(err.^2));
    lam=FF.Lambda(lamid);
    [beta_hatF,FF2]=lasso(xs(:,2:end),ys,'Lambda',lam);
    alfa_hatF=FF2.Intercept;
    fetempF=y(n+1)-alfa_hatF-x(n+1,:)*beta_hatF;
    feF=[feF;fetempF];
    betaF(n-m+1,1)=alfa_hatF;
    betaF(n-m+1,2:end)=beta_hatF;
    
    % cross-validated LASSO
    CrossVal = cvglmnet(xs(:,2:end),ys,[],[],[],m);
    cvindex1=find(CrossVal.glmnet_fit.lambda==CrossVal.lambda_min);     % min cv
    beta_hat1=CrossVal.glmnet_fit.beta(:,cvindex1);
    alfa_hat1=CrossVal.glmnet_fit.a0(cvindex1);
    fetemp1=y(n+1)-alfa_hat1-x(n+1,:)*beta_hat1;
    fe1=[fe1;fetemp1];
    beta1(n-m+1,1)=alfa_hat1;
    beta1(n-m+1,2:end)=beta_hat1;
    
    % fixed penalty LASSO
    [beta_hat2,F2]=lasso(xs(:,2:end),ys,'Lambda',0.1*log(nx2)/sqrt(m));         % fixed value of lambda
    alfa_hat2=F2.Intercept;
    %cvlambda2(ns,sim)=CrossVal.lambda_min;
    fetemp2=y(n+1)-alfa_hat2-x(n+1,:)*beta_hat2;
    fe2=[fe2;fetemp2];
    beta2(n-m+1,1)=alfa_hat2;
    beta2(n-m+1,2:end)=beta_hat2;
    
    % elastic-net
    opts=struct('alpha',0.5);
    options=glmnetSet(opts);
    CrossVe = cvglmnet(xs(:,2:end), ys, [], options, [], m, [], 'true');
    cvind=find(CrossVe.glmnet_fit.lambda==CrossVe.lambda_min);     % min cv
    beta_hatE=CrossVe.glmnet_fit.beta(:,cvind);
    alfa_hatE=CrossVe.glmnet_fit.a0(cvind);
    fetempE=y(n+1)-alfa_hatE-x(n+1,:)*beta_hatE;
    feE=[feE;fetempE];
    betaE(n-m+1,1)=alfa_hatE;
    betaE(n-m+1,2:end)=beta_hatE;

end

%% calculate measures of forecasting accuracy
MSE0=mean(fe0.^2);      % OLS kitchen sink
MSEC=mean(feC.^2);      % constant only
MSEA=mean(feA.^2);      % AR(1) model
MSER=mean(feR.^2);      % random walk

MSEM=mean(feM.^2);      % forecast combination
MSEF=mean(feF.^2);      % forward chaining LASSO
MSE1=mean(fe1.^2);      % cross validated LASSO
MSE2=mean(fe2.^2);      % fixed penalty LASSO
MSEE=mean(feE.^2);      % elastic-net

% calculate out-of-sample R-square using OLS as the benchmark
Rsq=zeros(1,4);
Rsq(1)=1-MSEC/MSE0;
Rsq(2)=1-MSEA/MSE0;
Rsq(3)=1-MSER/MSE0;

Rsq2=zeros(1,5);
Rsq2(1)=1-MSEM/MSE0;
Rsq2(2)=1-MSEF/MSE0;
Rsq2(3)=1-MSE1/MSE0;
Rsq2(4)=1-MSE2/MSE0;
Rsq2(5)=1-MSEE/MSE0;

%% test for statistical significance of the squared forecast error
CPApval=zeros(1,9);
[ ~, ~, CPApval(1), ~, ~ ] = CPAtest(feC.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(2), ~, ~ ] = CPAtest(feA.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(3), ~, ~ ] = CPAtest(feR.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(5), ~, ~ ] = CPAtest(feM.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(6), ~, ~ ] = CPAtest(feF.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(7), ~, ~ ] = CPAtest(fe1.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(8), ~, ~ ] = CPAtest(fe2.^2,fe0.^2,1,0.05,2);
[ ~, ~, CPApval(9), ~, ~ ] = CPAtest(feE.^2,fe0.^2,1,0.05,2);

SPApval=zeros(1,10);
SPApval(1)=bsds(fe0.^2, [feC.^2 feA.^2 feR.^2 feM.^2 feF.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(2)=bsds(feC.^2, [fe0.^2 feA.^2 feR.^2 feM.^2 feF.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(3)=bsds(feA.^2, [fe0.^2 feC.^2 feR.^2 feM.^2 feF.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(4)=bsds(feR.^2, [fe0.^2 feC.^2 feA.^2 feM.^2 feF.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(6)=bsds(feM.^2, [fe0.^2 feC.^2 feA.^2 feR.^2 feF.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(7)=bsds(feF.^2, [fe0.^2 feC.^2 feA.^2 feR.^2 feM.^2 fe1.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(8)=bsds(fe1.^2, [fe0.^2 feC.^2 feA.^2 feR.^2 feM.^2 feF.^2 fe2.^2 feE.^2], 10000, 1);
SPApval(9)=bsds(fe2.^2, [fe0.^2 feC.^2 feA.^2 feR.^2 feM.^2 feF.^2 fe1.^2 feE.^2], 10000, 1);
SPApval(10)=bsds(feE.^2, [fe0.^2 feC.^2 feA.^2 feR.^2 feM.^2 feF.^2 fe1.^2 fe2.^2], 10000, 1);


%% display the results for forecasting accuracy
format long
disp('   ');
disp('One-step ahead mean squared prediction error');
disp('   ');
disp('        OLS all        constant only         AR(1) model          random walk          principal');
disp('         comb          forward LASSO          LASSO_min           LASSO_fixed         elastic net');
disp([MSE0 MSEC MSEA MSER 0; MSEM MSEF MSE1 MSE2 MSEE]);

disp('   ');
disp('Out-of-sample R-square using OLS as benchmark');
disp('   ');
disp('        OLS all        constant only         AR(1) model          random walk          principal');
disp('         comb          forward LASSO          LASSO_min           LASSO_fixed         elastic net');
disp([ 0 Rsq; Rsq2]);

format short
disp('   ');
disp('Giacomini-White test for conditional predictive ability: p-values');
disp('   ');
disp('             constant    AR(1)    r-walk     PCA');
disp('     comb     LASSO_f   LASSO1    LASSO2     e-net');
disp(reshape([0 CPApval],5,2)');

disp('   ');
disp('Hansen test for superior predictive ability: p-values');
disp('   ');
disp('      OLS    constant    AR(1)    r-walk     PCA');
disp('     comb     LASSO_f   LASSO1    LASSO2     e-net');
disp(reshape(SPApval,5,2)');


save('Goyal_cointegration_result_20year');


toc;