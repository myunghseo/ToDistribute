clear;
clc;

nx2=50;
nsim=129;

rA1=nan(nx2^2,nsim);    % store the AR(1) coefficient matrix
rA2=nan(nx2^2,nsim);    % store the AR(2) coefficient matrix
rEG=nan(1,nsim);        % store the largest eigenvalue
idx=[];                 % record the discarded simulations

seed=1438317;
rng(seed);

for sim=1:nsim
    A1=randn(nx2)/12.25;
    A2=randn(nx2)/20;
    rEG(sim)=max(abs(eig([ A1 A2; eye(nx2) zeros(nx2) ])));
    
    if rEG(sim)<0.8
        rA1(:,sim)=reshape(A1,nx2^2,1);
        rA2(:,sim)=reshape(A2,nx2^2,1);
    else
        disp(['simulation no. ' num2str(sim) ' discarded']);
        idx=[idx; sim];
    end
end

rA1(:,idx)=[];
rA2(:,idx)=[];
rEG(idx)=[];
nsim=nsim-length(idx);

filename=['AR2coeff_p=' num2str(nx2) '_ndgp=' num2str(nsim) '.mat'];
save(filename,'nx2','nsim','rA1','rA2','rEG');


