function [V,r]=CItest(y)

[nobs,nvar]=size(y);
yt=y(2:end,:);
lyt=y(1:end-1,:);

s00=(yt'*yt)/nobs;
s01=(yt'*lyt)/nobs;
s10=(lyt'*yt)/nobs;
s11=(lyt'*lyt)/nobs;
[V,D]=eig(s01*(s11\s10),s00);
[ev,idx]=sort(diag(D),'descend');   % sort the sample squared canonical correlation

V=V(:,idx);
U=V'*s00*V;
V = bsxfun(@rdivide,V,sqrt(diag(U))');

if ev(1)<=1-sqrt(log(nobs)/nobs);
    r=nvar;
else
    cr=zeros(nvar,1);
    for k=0:nvar-1
        lm=mean(ev(1:nvar-k))/geomean(ev(1:nvar-k));
        cr(k+1)=nobs*(nvar-k)*log(lm)+k*(2*nvar-k+1)*log(nobs)/2;
    end
    [~,id]=min(cr);
    r=id-1;
end


