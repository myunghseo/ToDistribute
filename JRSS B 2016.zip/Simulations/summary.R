load('sim_001.RData')
big.result = result[,2:(nx*2+2)]

big.result = cbind(big.result,rep(NA,nrow(big.result)))
# big.result = [tauhat, betahat, gammahat, Predicition Error] 


for (i in 1:nrow(big.result)) {
  newdat = dgp(nobs=400, nx=nx)
  x = as.matrix(newdat[,2:(nx+1)])
  xhat = cbind(x, x*(newdat[,nx+2] < big.result[i,1]))   
  yhat = xhat %*% big.result[i,(2:(nx*2+1))]
  x_0 = cbind(x, x*(newdat[,nx+2] < true.par[1]))  
  g_0 = x_0 %*% true.par[2:length(true.par)]
  big.result[i,ncol(big.result)] = apply((g_0-yhat)^2,2,mean)
}



mean.pe = round(mean(big.result[,ncol(big.result)]),3)
median.pe = round(median(big.result[,ncol(big.result)]),3)
sd.pe = round(sd(big.result[,ncol(big.result)]),3)
mad.tau =round(mean(abs(big.result[,1]-true.par[1])),3)



ap.hat.stack = big.result[,-c(1,ncol(big.result))]
M.ap.hat.stack = apply((ap.hat.stack!=0),1,sum)
mean.M.ap.hat = round(mean(M.ap.hat.stack),3)


l1.error.ap.hat = apply(abs(ap.hat.stack-matrix(true.par[-1],nrep,nx*2,byrow=T)),1,sum)
mean.l1.error.ap.hat = round(mean(l1.error.ap.hat),3)

cat("jump=",jump,'\n')
cat("A =",A,'\n')
cat("summary of lambdas=",'\n')
print(summary(result[,1]))

cat('Mean(PE)  Median(PE) sd(PE)  E[M(ap.hat)] E|ap.hat-ap0|_1  E|tau.hat-tau0|   ','\n')
cat(mean.pe,"   ",median.pe,"    ", sd.pe,"   ",mean.M.ap.hat,"        ", mean.l1.error.ap.hat, "          ",mad.tau,"  ",'\n')

#print.result=paste(mean.pe," & ",median.pe," & ", sd.pe," & &", mb.tau," & ",rmse.tau,"\\")

save.image(paste(dic,"/summary_",nobs,".RData",sep=""))

