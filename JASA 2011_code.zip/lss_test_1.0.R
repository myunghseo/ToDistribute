# Purpose:
#	To calculate the p-value of LSS test for detecting threshold effects.
#
# Model:
#	Y = h(g(w,theta,gamma), U)
#	g(w;theta,gamma) = (w,theta,gamma) = x'beta + z'alpha*I(thres>gamma)
#	where W=(X,Z,THRES), theta=(beta,alpha).
#	H0: alpha=0
#	H1: alpha!=0
#
# Input:
#	y,x,z,thres: see the above equation. x and z should have a vector of 1's explicitly to include the intercept and intercept shift.
#	type: 
#		ls: least squares
#		qn: quantile
#		mse: maximum score estimation
#		mre: maximum rank correlation
#		probit: probit
#		logit : logit
#	grid.gamma: Grid points to search for gamma.
#		Default-- [10-th percentile of thres, 90-th percentile of thres].
#	J: the number of simulations for calculating a simulated p-value.
#		Default is 2000.
#	qn.tau: Used only in the Quantile regression. 
#		The quantile level only required the quantile regression
#		Default value is 0.5
#	iid: Used only in the Quantile regression. Denotes if errors are iid.
#		Default is TRUE.
#	size: The significance level of the test. 
#		Default is 0.05 (5%). 
#	hn: Block length for subsamples in MSE
#	nb: Number of bootstrap subsamples in MSE
#
# Output:
#	qlr= q.hat - q.tilde; the lss test statistic
#	p.value: the p.value of the LSS test
#	rej: TRUE if it reject the null hypothesis given the size
#
# Please see, for details,
#	Lee, Seo, Shin (2011), "Thesting for Threshold Effects in Regression Models", JASA 493 (106), pp. 220-231.
#
# 
# Last Updates: May/19/2013
#


lss.test <- function(y,x,z,thres,type=c('ls','qn','mse','mre','probit','logit'),grid.gamma='default',J=2000,qn.tau=0.5,iid=TRUE, size=0.05, hn, nb){

nobs <- length(y)
if (grid.gamma =='default') grid.gamma <- sort(thres)[round(nobs*0.1):round(nobs*0.9)]


#-----------------------------------------------------------------------------------------------
# Quantile Regression
#-----------------------------------------------------------------------------------------------
if (type=='qn'){
	require(quantreg)
 	U.J = qn.tau-(matrix(runif(J*nobs),J,nobs) < qn.tau)


	# Quantile regression under the null

	m.qr.null <- rq(y~x,tau=qn.tau) 
	u.tilde <- m.qr.null$resid
	q.tilde <- -(m.qr.null$rho / nobs)
	bdw <- 1.06*sd(u.tilde)*(nobs^(-1/5))
	x.1 <- cbind(1,x)	# The intercept should be added to calculate the variance term.

	if (iid) {
		V.tilde <- (t(x.1)%*%x.1/nobs) * (sum(dnorm(u.tilde/bdw))/(nobs*bdw)) # estimation under iid
	}
	else {
		V.tilde <- (t(x.1)%*%diag(dnorm(u.tilde/bdw))%*%x.1)/(nobs*bdw) # estimation under nonid
	}
	G.tilde = (U.J%*%x.1)/sqrt(nobs)
	D.tilde = diag(G.tilde%*%solve(V.tilde)%*%t(G.tilde))

	
	# Qeantile regression under the altenative		

	n.grid <- length(grid.gamma)
	q.hat.i <- rep(NA,n.grid)
	D.mat <- matrix(NA,n.grid,J)
	for (i in c(1:n.grid)){
		w.gm <- cbind(x,z*(thres>grid.gamma[i]))
		m.qr.alter <- rq(y~w.gm,tau=qn.tau)
		q.hat.i[i] <- -(m.qr.alter$rho / nobs)
		w.gm.1 = cbind(1,w.gm)	# The intercept should be added to calculate the variance term.

		if (iid) {
 			V.gm <- ( t(w.gm.1)%*%w.gm.1 / nobs ) * ( sum(dnorm(u.tilde/bdw)) / (nobs*bdw) )  # estimation under iid
		}
		else {
			V.gm <- (t(w.gm.1)%*%diag(dnorm(u.tildea/bdw))%*%w.gm.1)/(nobs*bdw) # estimation under nonid
		}
		G.J = (U.J%*%w.gm.1)/sqrt(nobs)
		D.hat <- diag(G.J%*%solve(V.gm)%*%t(G.J))
		D.mat[i,] <- D.hat
		
	}

	
	# QLR test statistic

	qlr <- nobs * (max(q.hat.i)-q.tilde)


	# p-value

	qlr.J = (apply(D.mat,2,max)-D.tilde)/2
   	pv = mean( qlr.J > qlr)
  	rej = (pv < size)

	return(list(qlr=qlr,pv=pv,rej=rej))
}

#-----------------------------------------------------------------------------------------------
# Maximum Score Estimation
#-----------------------------------------------------------------------------------------------
if (type=='mse'){

# Grid for searching beta. Only for the given simulation design. Other optimization algorithm
# should be adopted for higher dimensional beta.
	grbt = seq(0,1,by=0.04)		
	

	maxscl <- function(y,x1,grbt=grbt) {
		mscore = -nobs
		for (i1 in (1:length(grbt))) {
			bt1i = grbt[i1]
			score1 = t(2*y -1) %*% ( (-sqrt(1-bt1i^2) + bt1i*x1) > 0 )
			score2 = t(2*y -1) %*% ( (sqrt(1-bt1i^2) + bt1i*x1) > 0 )
			scorei = max(c(score1,score2))
			if (scorei > mscore) mscore = scorei 
		}
		return(mscore*(nobs^(-1/3)))
	}

	maxsct <- function(y,x1,x2,q,grbt=grbt,grgm=grid.gamma) {
		mscore = -nobs

		for (i1 in (1:length(grgm))) {
			di = (q>grgm[i1])
			x1i = x1
			x2i = x2 * di
			for (i2 in (1:length(grbt))){
				bt1i = grbt[i2]
				grbt2 = seq(-sqrt(1-bt1i^2),sqrt(1-bt1i^2),by=0.04)
				for (i3 in (1:length(grbt2))){
					bt2i = grbt2[i3]
					score1 = t(2*y-1) %*% ( (-sqrt(max(c(0,1-bt1i^2-bt2i^2))) + bt1i*x2i + bt2i*x1i) > 0 )
					score2 = t(2*y-1) %*% ( (sqrt(max(c(0,1-bt1i^2-bt2i^2))) + bt1i*x2i + bt2i*x1i) > 0 )
					scorei = max(c(score1,score2))
					if (scorei > mscore) mscore = scorei 			
				}
			}			
		}
		return(mscore*(nobs^(-1/3)))
	}

	qlr = maxsct(y,x,z,thres,grbt=grbt,grgm=grid.gamma)-maxscl(y,x,grbt=grbt)

	# hm out of n bootstrap
	bqlr = rep(NA,nb)
	for (ib in (1:nb)){
		idx = sample(c(1:nobs),hn)
		b.grid.gamma <- sort(thres[idx])[round(hn*0.1):round(hn*0.9)]
		bqlr[ib] = maxsct(y[idx],x[idx],z[idx],thres[idx],grbt=grbt,grgm=b.grid.gamma)-maxscl(y[idx],x[idx],grbt=grbt)
	}

	# p-value
	pv = mean(bqlr > qlr)
  	rej = (pv < size)

	return(list(qlr=qlr,pv=pv,rej=rej))

}



}

