##############################################

# READ Me : 
# put RDS files in subfolder named " ./funct/ "

##############################################

###: Chow test at gm and related statistics

Chowtest <- function(y,X,gm,B=200){
  # Chow Test,  
  # X must include 1's
  # outputs : c("Tboot",pval,"Wn",pval)
  
  p <- ncol(X)
  OLS_out <- OLS_BT_g(y,X,gm,B=B) 
  Wn <- OLS_out[1]
  Tboot <- (OLS_out[1] - OLS_out[3])/sqrt(2*p*OLS_out[2])
#  Qn <- (OLS_out[1] - p)/sqrt(2*p)
#  pnorm(Qn)  
  return(c(Tboot,pTn(Tboot,gm),Wn,(1-pchisq(Wn,p)))) 
}

OLS_BT_g <- function(y,X,gm,B=200){
  # X is assumed to include 1's
  # outputs : "Wn","HAR","Wnst"
  
  n <- length(y)
  p <- ncol(X)
  t <- seq(1/n,n/n,by=1/n)
  
  X1 <- cbind(X, X * (t>gm))
  
  iM <- tryCatch(solve(t(X1) %*% X1), error=function(e) ginv(t(X1) %*% X1))
  bhat <-  iM %*% t(X1) %*% y
  ehat <-  y - X1 %*% bhat
  dhat <- bhat[-(1:p)]
  
  R <- cbind(matrix(0,p,p),diag(1,p,p))
  X1e <- X1 * as.vector(ehat)
  Omega_g <- t(X1e) %*% X1e
  
  Wn <- dhat %*% solve(R %*% iM %*% Omega_g %*% iM %*% t(R)) %*% dhat
  
  ############################
  #- HAR -#
  
  Xe <- X * as.vector(ehat)
  iOmega <- n*solve(t(Xe) %*%  Xe)
  iOmega2 <- t(chol(iOmega))
  
  Xtild <- Xe %*% iOmega2
  cXtil <- apply(Xtild, 2, cumsum)
  vt <- apply(cXtil[-n,]*Xtild[-1,],1,sum)/sqrt((n-1)*p)
  
  vtil <- vt- mean(vt)
  kr <- kern(n-1)
  HAR <- 2*vtil %*% kr %*% vtil  /n
  
  ###############################
  #- Bootstrap Bias Correction -#
  
  Wnst <- vector()
  for (i in 1:B) {
    
    est <- ehat*(2*(rnorm(n) > 0)-1)
    yst <- X %*% (solve(t(X)%*% X) %*% t(X) %*%y) + est
    bsthat <-  iM %*% t(X1) %*% (yst)
    esthat <-  yst - X1 %*% bsthat
    dsthat <- bsthat[-(1:p)]
    
    X1est <- X1 * as.vector(esthat)
    Omega_gst <- t(X1est) %*% X1est
    
    Wnst <- c(Wnst,dsthat %*% solve(R %*% iM %*% Omega_gst %*% iM %*% t(R)) %*% dsthat)
    
  }
  Wnst <- mean(Wnst)
  
  return(c(Wn,HAR,Wnst))
}

kern <- function(n){ D <- matrix(NA,n,n)
for (i in 1:n){   for (j in 1:n){D[i,j] <- (1-abs(i-j)/n)}}
return(D)
}

###: Wald test for exclusion

Exc_test <- function(y,X,p1,B=200){
  # Test of bt2 = 0, where bt=(bt1,bt2), dim(bt2)=p1 
  # output: T, p-value and Wn, p-values 
  
  OLS_out <- OLS_BT_dt(y,X,p1,B=B) # exclusion test for last p elements
  
  Wn <- OLS_out[1]
  Qn <- (OLS_out[1] - p1)/sqrt(2*p1)
  Tboot <- (OLS_out[1] - OLS_out[3])/sqrt(2*p1*OLS_out[2])
  
  p_val <-c(Tboot,p_Tn_W(Tboot),Wn, pchisq(Wn,df=p1,lower.tail = FALSE) )
  
  return(p_val)
}

###: Wald test for R*beta = r

Lin_test <- function(Y,Z,R,r,B=200){
  # Test of R %*% beta = r 
  # output: T, p-value and Wn, p-values 
  
  p <- ncol(R); p1 <- nrow(R)  
  
  Rc <- (qr.Q(qr(t(R)),complete=TRUE)[,(nrow(R)+1):ncol(R)]) 
  Q=rbind(Rc,R)
  
  X <- Z %*% solve(Q) 
  
  y <- Y - X[,-(1:(p-p1))]%*%r
  
  bt <- solve(t(Z)%*%Z)%*%t(Z)%*%Y
  bt1 <- solve(t(X)%*%X)%*%t(X)%*%y
  print(R %*% bt - r - bt1[-(1:(ncol(R)-nrow(R)))])
  
  
  OLS_out <- OLS_BT_dt(y,X,p1,B=B) # exclusion test for last p elements
  
  Wn <- OLS_out[1]
  Qn <- (OLS_out[1] - p1)/sqrt(2*p1)
  Tboot <- (OLS_out[1] - OLS_out[3])/sqrt(2*p1*OLS_out[2])
  
  p_val <-c(Tboot,p_Tn_W(Tboot),Wn , pchisq(Wn,df=p1,lower.tail = FALSE) )
  
  return(p_val)
}

OLS_BT_dt <- function(y,X,p1,B=200){# X is assumed to include 1's
  # exclusion test for last p1 elements
  n <- length(y)
  p <- ncol(X)
  p2 <- p-p1
  
  iM <- tryCatch(solve(t(X) %*% X), error=function(e) ginv(t(X) %*% X))
  bhat <-  iM %*% t(X) %*% y
  ehat <-  y - X %*% bhat
  dhat <- bhat[-(1:p2)]
  
  X1 <- X[,1:p2]; X2 <- X[,(p2+1):p]
  X2t <- X2 - X1 %*% solve(t(X1) %*% X1, t(X1) %*% X2)
  iM2 <- tryCatch(solve(t(X2t) %*% X2t), error=function(e) ginv(t(X2t) %*% X2t))
  
  X2e <- X2t * as.vector(ehat)
  Omega <- t(X2e) %*% X2e
  
  Wn <- dhat %*% solve(iM2 %*% Omega %*% iM2) %*% dhat
  
  ############################
  #- HAR -#
  
  iOmega <- n*solve(t(X2e) %*%  X2e)
  iOmega2 <- t(chol(iOmega))
  
  Xtild <- X2e %*% iOmega2
  cXtil <- apply(Xtild, 2, cumsum)
  vt <- apply(cXtil[-n,]*Xtild[-1,],1,sum)/sqrt((n-1)*p1)
  
  vtil <- vt- mean(vt)
  kr <- kern(n-1)
  HAR <- 2*vtil %*% kr %*% vtil  /n
  HAC <- 2*vtil %*% vtil  /n
  
  ###############################
  #- Bootstrap Bias Correction -#
  
  Wnst <- vector()
  for (i in 1:B) {
    
    est <- ehat*(2*(rnorm(n) > 0)-1)
    yst <- X1 %*% solve(t(X1) %*% X1) %*% t(X1) %*% y  +  est
    
    bsthat <-  iM %*% t(X) %*% (yst)
    esthat <-  yst - X %*% bsthat
    dsthat <- bsthat[-(1:p2)]
    
    X2est <- X2t * as.vector(esthat)
    Omega_st <- t(X2est) %*% X2est
    
    Wnst <- c(Wnst,dsthat %*% solve(iM2 %*% Omega_st %*% iM2) %*% dsthat)
  }
  Wnst <- mean(Wnst)
  
  return(c(Wn,HAR,Wnst,HAC))
}



#######################################################
###: Compute ap-quantile for Chow test (gm), Wald test

qTn <- function(gm,ap){ # for general ap
  val <- readRDS("./funct/out_Tn.RDS")
  val <- val[(1+(gm-0.1)/0.005),]
  return(quantile(val,ap))
}
###: p-value for Chow test (gm)
pTn <- function(Tn,gm){ # for general ap
  val <- readRDS("./funct/out_Tn.RDS")
  val <- val[(1+(gm-0.1)/0.005),]
  return(mean(val>Tn))
}
###: p-value for Wald test
p_Tn_W <- function(Tn){
  val <- readRDS("./funct/out_t_n_Wald.RDS")
  return(mean(val > Tn))
}