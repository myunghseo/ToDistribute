rm(list=ls())
start.time <- proc.time()[3]
cat(date(), file='growth_app_lr_linear_out.asc', sep='\n', append=F)


library('lars')
###########################################################
# Data read and construction
###########################################################
g_data <- read.table('new_data_lr.cvs')

dep <-g_data[,'gr']
reg <-as.matrix(g_data[,c(4:ncol(g_data))])
reg <- cbind(reg)
thres <- g_data[,'lr']

nx <- ncol(reg)
nobs <- nrow(reg)
sorted.thres <- sort(thres)
trim.factor <- round(length(sorted.thres)*.10,0)
grid.tau <- sorted.thres[trim.factor:(nobs-trim.factor)]

reg.names <- colnames(reg)



gfit <- lars(reg,dep,type='lasso')
pdf('lr_linear.pdf')
plot(gfit,plottype='coefficients')
plot(gfit,plottype='Cp')

cv.gfit<-cv.lars(reg,dep,K=nobs,index=seq(from=0,to=1,length=1000),type='lasso',trace=T, mode='fraction')
frac <- cv.gfit$index[which.min(cv.gfit$cv)]
gfit.coef <- predict.lars(gfit,type='coefficient',mode='fraction',s=frac)
dev.off()


# intercept estimator: ahat = E(Y) - E(X)'bhat
alpha.hat <- mean(dep) - apply(reg,2,mean) %*% gfit.coef$coefficient

cat(cat('\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
out<-capture.output(gfit.coef)
cat(out, file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
cat(cat('\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
out<-capture.output(alpha.hat)
cat(c('alpha.hat=',out), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	







##############################################################
# Find the lambda corresponding to the best cross validation
##############################################################
betas <- gfit$beta
lambdas <- gfit$lambda
sbetas <- scale(betas, FALSE, 1/gfit$normx)
kp <- dim(betas)
k<-kp[1]
p<-kp[2]

nbeta <- drop(abs(sbetas) %*% rep(1,p))
sbeta <- nbeta/nbeta[k]
coord <- approx(sbeta,seq(sbeta),frac)$y
left<-floor(coord)
right<-ceiling(coord)
newlambda <- ((sbeta[right]-frac)*lambdas[left] + (frac-sbeta[left])*lambdas[right]) / (sbeta[right]-sbeta[left])
cat('lambda =',newlambda)

cat(cat('\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
cat(c('lambda =',newlambda), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	


######################
# Calculate R-squared
#######################
R2.set <- gfit$R2
R2 <- approx(seq(R2.set),R2.set,coord)$y
cat('R-squared =',R2,'\n')


#gfit.yhat <- predict.lars(gfit,newx=reg,type='fit',mode='fraction',s=frac)$fit
#tss <- sum((dep-mean(dep))^2)
#rss <- sum((dep-gfit.yhat)^2)
#r2 <- 1-(rss/tss)
#cat('R-squared = ',r2,'\n')

cat(cat('\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
cat(c('R-squared = ',R2,'\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	


sst_etilde <- min(cv.gfit$cv)*nobs
sst_y <- sum(dep^2)
tildeR2 <- 1- sst_etilde/sst_y
cat('R-tilde-squared =',tildeR2,'\n')
cat(cat('\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	
cat(c('R-tilde-squared = ',tildeR2,'\n'), file='growth_app_lr_linear_out.asc', sep='\n', append=T)	







# Print computation time & save the result    
runt <- proc.time()[3]-start.time
runt_h <- floor(runt/3600)
runt_m <- floor( (runt/3600 - runt_h) * 60 )
runt_s <- floor( (runt/60 - (runt_h*60) - runt_m) * 60 )
cat('\n',"runtime = ",runt_h,"h",runt_m,"m",runt_s,"s",'\n','\n')
cat('-----------------------------------------------------------','\n')






