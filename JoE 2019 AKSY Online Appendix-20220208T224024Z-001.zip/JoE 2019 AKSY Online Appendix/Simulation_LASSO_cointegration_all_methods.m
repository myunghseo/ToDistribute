%% Initialisation
clc; 
clear;
warning('off','all')

tic;

%% Preparation
nsim=5000;      % number of simulation
% number of observation
sizes=[ 100; 200; 400; 1000 ];
nsize=length(sizes);
npre=1000;      % number of pre-sample
nprd=1;         % forecasting horizon
nvar=10;        % number of predictor
nx1=4;          % number of persistent predictor
nx2=nvar-nx1;   % number of non-persistent predictor

% coefficient matrix
delta=[1; -0.5; 0; 0];                      % cointegrating vector
alpha=[0; 0.3; 0; 0.2];                     % loading
A1=alpha*delta'+eye(nx1);                   % coefficient matrix for persistent predictors
A2=0.4*eye(nx2);                            % coefficient matrix for non-persistent predictors
beta=[0.3*delta' -0.1 0 0.02 0.4 0 -0.2];   % coefficients in the predictive regression
c=0.15;                                     % constant term
%A2(6,6)=0.1;
A2(2:5, 2:5)=[ 1.31 0.29  0.12 0.04;
              -0.21 1.25 -0.24 0.04;
               0.07 0.03  1.16 0.01;
               0.08 0.27 -0.07 1.25 ];
A3=zeros(nx2);
A3(2:5,2:5)=[ -0.35 -0.28 -0.07 -0.02;
               0.19 -0.26  0.24 -0.05;
              -0.07 -0.02 -0.16  0.01;
              -0.13 -0.23  0.03 -0.31 ];
cst=zeros(1,nx2); %[ 0.03 -0.04 0.22 -0.11 0.09 0.05 ];


%% simulate the DGP
for ns=1:length(sizes)
    
    seed=1438240+2*(ns-1);
    rng(seed);
    
    nobs=sizes(ns);
    h=floor(0.1*nobs);      % evaluation window size for forward chaining LASSO
    
    fe0=[];     % OLS kitchen sink
    feC=[];     % constant only
    feA=[];     % AR(1) model
    feR=[];     % random walk
    feP=[];     % principal component
    
    feM=[];     % forecast combination
    feF=[];     % LASSO_{forward chaining}
    fe1=[];     % LASSO_min
    fe2=[];     % LASSO_fix
    feE=[];     % elastic-net

    for sim=1:nsim
        
        % error terms with no contemporaneous correlation
        et=randn(nobs+npre+nprd,nvar+1);
        y=zeros(size(et));
        % first observation
        y(1,:)=et(1,:);
        % second observation
        y(2,1)=c+y(1,2:end)*beta'+et(2,1);
        y(2,1+1:1+nx1)=y(1,1+1:1+nx1)*A1'+et(2,1+1:1+nx1);
        y(2,1+nx1+1:end)=cst+y(1,1+nx1+1:end)*A2'+et(2,1+nx1+1:end);
        
        for i=3:size(y,1)
            y(i,1)=c+y(i-1,2:end)*beta'+et(i,1);
            % cointegrated persistent variables
            y(i,1+1:1+nx1)=y(i-1,1+1:1+nx1)*A1'+et(i,1+1:1+nx1);
            % non-persistent variables
            y(i,1+nx1+1:end)=cst+y(i-1,1+nx1+1:end)*A2'+y(i-2,1+nx1+1:end)*A3'+et(i,1+nx1+1:end);
        end
        
        % estimation sample
        ys=y(npre+1:npre+nobs,1);
        xs=y(npre:npre+nobs-1,2:end);
        yslag=y(npre:npre+nobs-1,1);
        
        % forecast sample
        yf=y(npre+nobs+1:npre+nobs+nprd,1);
        xf=y(npre+nobs:npre+nobs+nprd-1,2:end);
        
        
        %% ----------- Simple Models ----------- %%
        % OLS regression -- kitchen sink model
        [beta_hat0,~,~,~,stat0] =regress(ys, [ones(nobs,1) xs]);
        fetemp0=yf-[ones(length(yf),1) xf]*beta_hat0;
        fe0=[fe0;fetemp0];
        
        % Constant only -- historical average
        [alfa,~,~,~,statC]=regress(ys,ones(nobs,1));
        fetempC=yf-alfa;
        feC=[feC;fetempC];
        
        % AR(1) model
        [rho,~,~,~,statA]=regress(ys,[ones(nobs,1) yslag]);
        fetempA=yf-[1 ys(end)]*rho;
        feA=[feA; fetempA];
        
        % random walk model
        fetempR=yf-ys(end);
        feR=[feR;fetempR];
        
        % principal component with standardised variables
        xstd=xs(:,nx1+1:end)-mean(xs(:,nx1+1:end));
        xstd=xstd./repmat(std(xstd),nobs,1);
        xfstd=xf(:,nx1+1:end)-mean(xf(:,nx1+1:end));
        xfstd=xfstd./repmat(std(xfstd),length(yf),1);
        
        coeffs=pca(xstd);
        beta_hatps=regress(ys,[ones(nobs,1) xs(:,1:nx1) xstd*coeffs(:,1:4)]);
        fetempPs=yf-[ones(length(yf),1) xf(:,1:nx1) xfstd*coeffs(:,1:4)]*beta_hatps;
        feP=[feP;fetempPs];


        %% --------- forecast combination --------- %%
        ftempM=zeros(size(xs,2),1);
        for i=1:size(xs,2)
            btempM=regress(ys,[ones(nobs,1) xs(:,i)]);
            ftempM(i)=[ones(length(yf),1) xf(:,i)]*btempM;
        end
        fetempM=yf-mean(ftempM);
        feM=[feM; fetempM];

        
        %% ----------- Homo L1 Penalty ----------- %%
        % forward chaining LASSO
        [bF,FF] = lasso(xs(1:nobs-h,:),ys(1:nobs-h),'NumLambda',100);
        nlam=length(FF.Intercept);
        err=repmat(ys(nobs-h+1:nobs),1,nlam)-repmat(FF.Intercept,h,1)-xs(nobs-h+1:nobs,:)*bF;
        % find lambda that minimizes the forecast error
        [~,lamid]=min(sum(err.^2));
        lam=FF.Lambda(lamid);
        [beta_hatF,FF2]=lasso(xs,ys,'Lambda',lam);
        alfa_hatF=FF2.Intercept;
        fetempF=yf-alfa_hatF-xf*beta_hatF;
        feF=[feF;fetempF];
        
        % fixed penalty LASSO
        [beta_hat2,F2]=lasso(xs,ys,'Lambda',0.1*log(nx2)/sqrt(nobs));         % fixed value of lambda
        alfa_hat2=F2.Intercept;
        %cvlambda2(ns,sim)=CrossVal.lambda_min;
        fetemp2=yf-alfa_hat2-xf*beta_hat2;
        fe2=[fe2;fetemp2];
        
        % cross-validated LASSO
        CrossVal = cvglmnet(xs,ys,[],[],[],nobs);
        cvindex1=find(CrossVal.glmnet_fit.lambda==CrossVal.lambda_min);     % min cv
        beta_hat1=CrossVal.glmnet_fit.beta(:,cvindex1);
        alfa_hat1=CrossVal.glmnet_fit.a0(cvindex1);
        fetemp1=yf-alfa_hat1-xf*beta_hat1;
        fe1=[fe1;fetemp1];
    
        % elastic-net
        opts=struct('alpha',0.5);
        options=glmnetSet(opts);
        CrossVe = cvglmnet(xs, ys, [], options, [], nobs, [], 'true');
        cvind=find(CrossVe.glmnet_fit.lambda==CrossVe.lambda_min);     % min cv
        beta_hatE=CrossVe.glmnet_fit.beta(:,cvind);
        alfa_hatE=CrossVe.glmnet_fit.a0(cvind);
        fetempE=yf-alfa_hatE-xf*beta_hatE;
        feE=[feE;fetempE];


    end

    
    %% calculate measures of forecasting accuracy
    MSE0=mean(fe0.^2);      % OLS kitchen sink
    MSEC=mean(feC.^2);      % constant only
    MSEA=mean(feA.^2);      % AR(1) model
    MSER=mean(feR.^2);      % random walk
    MSEP=mean(feP.^2);      % principal component
    
    MSEM=mean(feM.^2);      % forecast combination
    MSEF=mean(feF.^2);      % forward chaining LASSO
    MSE1=mean(fe1.^2);      % cross validated LASSO
    MSE2=mean(fe2.^2);      % fixed penalty LASSO
    MSEE=mean(feE.^2);      % elastic-net
    
    % calculate out-of-sample R-square using OLS as the benchmark
    Rsq=zeros(1,4);
    Rsq(1)=1-MSEC/MSE0;
    Rsq(2)=1-MSEA/MSE0;
    Rsq(3)=1-MSER/MSE0;
    Rsq(4)=1-MSEP/MSE0;
    
    Rsq2=zeros(1,5);
    Rsq2(1)=1-MSEM/MSE0;
    Rsq2(2)=1-MSEF/MSE0;
    Rsq2(3)=1-MSE1/MSE0;
    Rsq2(4)=1-MSE2/MSE0;
    Rsq2(5)=1-MSEE/MSE0;


    %% display the results for forecasting accuracy
    format short
    disp('   ');
    disp('-----------------------------------------------------');
    disp('   ');
    disp(['sample size is --- ' num2str(nobs)]);
    
    format long
    disp('   ');
    disp('One-step ahead mean squared prediction error');
    disp('   ');
    disp('        OLS all        constant only         AR(1) model          random walk          principal');
    disp('         comb          forward LASSO          LASSO_min           LASSO_fixed         elastic net');
    disp([MSE0 MSEC MSEA MSER MSEP; MSEM MSEF MSE1 MSE2 MSEE]);
    
    disp('   ');
    disp('Out-of-sample R-square using OLS as benchmark');
    disp('   ');
    disp('        OLS all        constant only         AR(1) model          random walk          principal');
    disp('         comb          forward LASSO          LASSO_min           LASSO_fixed         elastic net');
    disp([ 0 Rsq; Rsq2]);

end


%% plot one of the simulated sample paths (the last one)
%{
fig1=figure;
set(fig1,'Position',[50, 50, 700, 800]);

subplot(3,1,1);
    set(gca,'YGrid','on','XGrid','on','FontSize',10,'XLim',[0 length(ys)], ...
        'YLim',[-20,15]);
    box on
    hold all
    plot(xs(:,5),'LineWidth',1,'Color',[0 0 0]);
    plot(xs(:,6),'LineWidth',1,'Color',[1 0.600000023841858 0.7843137383461]);
    plot(xs(:,7),'LineWidth',1,'LineStyle','--',...
    'Color',[0.301960796117783 0.745098054409027 0.933333337306976]);
    title('(a) simulated sample path of z_{1,t}, z_{2,t} and z_{3,t}');
    legend('z_{1,t}','z_{2,t}','z_{3,t}','Location','best','Orientation','horizontal');
subplot(6,1,3);
    set(gca,'YGrid','on','XGrid','on','FontSize',10,'XLim',[0 length(ys)], ...
        'Ylim',[floor(min(min(xs(:,1:2)))),ceil(max(max(xs(:,1:2))))]);
    box on
    hold all
    plot(xs(:,1),'Color',[1 0 0],'LineWidth',1);
    plot(xs(:,2),'Color',[0 0.498039215803146 0],'LineWidth',1,'LineStyle','--');
    title('(b) simulated sample path of x_{1,t}, x_{2,t} and x_{1,t}-0.5x_{2,t}');
    legend('x_{1,t}','x_{2,t}','Location','best','Orientation','horizontal');
subplot(6,1,4);
    set(gca,'YGrid','on','XGrid','on','FontSize',10,'XLim',[0 length(ys)], ...
        'Ylim',[floor(min(xs(:,1)-0.5*xs(:,2))),ceil(max(xs(:,1)-0.5*xs(:,2)))]);
    box on
    hold all
    plot(xs(:,1)-0.5*xs(:,2),'LineWidth',1,'LineStyle','-.',...
    'Color',[0.494117647409439 0.184313729405403 0.556862771511078]);
subplot(3,1,3);
    set(gca,'YGrid','on','XGrid','on','FontSize',10,'XLim',[0 length(ys)], ...
        'YLim',[floor(min(ys)),ceil(max(ys))]);
    box on
    hold all
    plot(ys,'LineWidth',1);
    title('(c) simulated sample path of y_t');
%}

toc

