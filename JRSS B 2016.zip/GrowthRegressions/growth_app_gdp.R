rm(list=ls())
start.time <- proc.time()[3]
cat(date(), file='growth_app_gdp_out.asc', sep='\n', append=F)

library('lars')
###########################################################
# Data read and construction
###########################################################
g_data <- read.table('new_data.cvs')

dep <-g_data[,'gr']
reg <-as.matrix(g_data[,c(5:ncol(g_data))])
reg <- cbind(1,reg)
thres <- g_data[,'gdp60']

nx <- ncol(reg)
nobs <- nrow(reg)
sorted.thres <- sort(thres)
trim.factor <- round(length(sorted.thres)*.10,0)
grid.tau <- sorted.thres[trim.factor:(nobs-trim.factor)]

colnames(reg) <- c('const',colnames(reg)[2:ncol(reg)])
reg.names <- colnames(reg)

###########################################################
# Threshold LASSO function
###########################################################
tlasso <- function (x, y, q, s, grid.tau) {

  ngrid <- length(grid.tau)
  nobs <- length(y)
  nreg <- ncol(x)*2
  delta.hat.grid <- matrix(rep(NA), nrow=ngrid, ncol=nreg)
  obj.v <- matrix(rep(NA), nrow=ngrid, ncol=1)
  norm.x <- matrix(rep(NA), nrow=1, ncol=nreg)
  delta.hat <- matrix(rep(NA), nrow=1, ncol=nreg)
  tau.hat <- NA
  for(i in 1:ngrid) {
    ind <- ( q < grid.tau[i] )
    x.reg <- cbind(x,x*ind)
    m <- lars(x.reg,y)
    delta.hat.grid[i,] <- coef(m, s=s, mode="lambda")
    yhat <- predict(m, s=s, mode="lambda",x.reg)$fit
    uhat <- y - yhat
    ssr <- t(uhat)%*%uhat / nobs
    for(j in 1:nreg){
	norm.x[1,j] <- sqrt( t((x.reg[,j]))%*% (x.reg[,j]) / (nobs) )
    }
    p <- norm.x %*% abs(delta.hat.grid[i,])
    obj.v[i,1] <- ssr + s*p    	
  }
    opt<-which.min(obj.v)
    delta.hat <- delta.hat.grid[opt,]
    tau.hat <- grid.tau[opt]



    rval <- list(model=m, est=c(s, tau.hat, delta.hat))

  return(rval)

}




####################################################
# Final model with lambda from cross validation
####################################################



	lambda <- 0.0034
	f.result <- tlasso(x=reg, y=dep, q=thres, s=lambda, grid.tau)
	f.model <- f.result$model
	f.coef<-f.result$est

	# R-squared calculation
	lambda.set <- f.model$lambda
	R2.set <- f.model$R2
	coord <- approx(lambda.set,seq(lambda.set),lambda)$y
	R2 <- approx(seq(R2.set),R2.set,coord)$y
	cat('R-squared =',R2,'\n')

    	
	is.beta.zero <- (f.coef[3:(nx+2)]==0)
   	is.delta.zero <- (f.coef[(nx+3):(nx*2+2)]==0)
	M.alpha <- (nx)*2 - sum(c(is.beta.zero,is.delta.zero)) + 1 # +1 is for the intercept
	cat('M(alpha) =',M.alpha,'\n')

	adj.R2 <- 1-(1-R2)*(nobs-1)/(nobs-M.alpha)
	cat('adj R-squared =', adj.R2,'\n')


	est.result<-cbind(f.coef[3:(nx+2)],f.coef[3:(nx+2)]+f.coef[(nx+3):(nx*2+2)], is.beta.zero, is.delta.zero )
	rownames(est.result) <- reg.names
	colnames(est.result) <- c('thres >= gam: beta','thres < gam: beta+delta', 'betahat =0?','deltahat =0?')

	# Intercept Estimation	
	alpha.hat <- mean(dep)-apply(cbind(reg,(thres<f.coef[2])*reg),2,mean)%*%f.coef[-c(1:2)]



	# Print out the result

	out<-capture.output(cat('# of observations = ', nobs, '\n'))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)
	
	out<-capture.output(cat('dim of X = ', nx,'\n'))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)
	
#	out<-capture.output(cat('lambda = ', lambda, '=',lambda_max, '/', i, '\n','\n'))
	out<-capture.output(cat('lambda = ', lambda, '\n','\n'))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)	

	out<-capture.output(cat('tauhat=',f.coef[2],'\n'))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)	

	out<-capture.output(cat('R2 = ', R2, '\n'))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)

	out<-capture.output(cat('M(alpha) =',M.alpha))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)

	out<-capture.output(cat('adj R-squared =', adj.R2))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)

	cat(cat('\n'), file='growth_app_gdp_out.asc', sep='\n', append=T)	
	out<-capture.output(print(est.result))
	cat(out, file='growth_app_gdp_out.asc', sep='\n', append=T)	

	cat(cat('\n'), file='growth_app_gdp_out.asc', sep='\n', append=T)	
	out<-capture.output(alpha.hat)
	cat(c('intercept=',out), file='growth_app_gdp_out.asc', sep='\n', append=T)	



# Print computation time & save the result    
runt <- proc.time()[3]-start.time
runt_h <- floor(runt/3600)
runt_m <- floor( (runt/3600 - runt_h) * 60 )
runt_s <- floor( (runt/60 - (runt_h*60) - runt_m) * 60 )
cat('\n',"runtime = ",runt_h,"h",runt_m,"m",runt_s,"s",'\n','\n')
cat('-----------------------------------------------------------','\n')










