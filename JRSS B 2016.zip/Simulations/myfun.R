dgp <- function(nobs, nx, delta0=c(1,1), delta1=c(-1,1)*jump, tau=true.par[1]) {
  y <- rep(NA, nobs)
  x <- matrix(rnorm(nobs*nx),nobs,nx)
  q <- runif(nobs)
  err <- rnorm(nobs)*sigma 

  y <- x[,c(1,3)] %*% delta0  + x[,c(2,3)] %*% delta1 * (q < tau) + err

  return(data.frame(y=y, x=x, q=q))
}


tlasso <- function (x, y, q, s, grid.tau, nonzero) {
  tau_0 <- true.par[1]
  alpha_10 <- c(1,0,1,rep(0,nx-3)) 
  alpha_20 <- jump*c(0,-1,1,rep(0,nx-3))  
  f0 <- x %*% alpha_10 + (q < tau_0) * (x %*% alpha_20)

  ngrid <- length(grid.tau)
  nobs <- length(y)
  nreg <- sum(nonzero)
  delta.hat.grid <- matrix(rep(NA), nrow=ngrid, ncol=nreg)
  obj.v <- matrix(rep(NA), nrow=ngrid, ncol=1)
  norm.x <- matrix(rep(NA), nrow=1, ncol=nreg)
  delta.hat <- matrix(rep(NA), nrow=1, ncol=nreg)
  tau.hat <- NA

  for(i in 1:ngrid) {
    ind <- ( q < grid.tau[i] )
    x.reg <- cbind(x,x*ind)
    x.reg <- x.reg[,nonzero]
    m <- lars(x.reg,y)
    delta.hat.grid[i,] <- coef(m, s=s, mode="lambda")
    yhat <- predict(m, s=s, mode="lambda",x.reg)$fit
    uhat <- y - yhat
    ssr <- t(uhat)%*%uhat / nobs
    for(j in 1:nreg){
	norm.x[1,j] <- sqrt( t((x.reg[,j]))%*% (x.reg[,j]) / (nobs) )
    }
    p <- norm.x %*% abs(delta.hat.grid[i,])
    obj.v[i,1] <- ssr + s*p    	
  }
    opt<-which.min(obj.v)

    delta.hat <- delta.hat.grid[opt,]
    delta.hat_1 <- delta.hat[1:nx]
    delta.hat_2 <- delta.hat[(nx+1):(2*nx)]
    tau.hat <- grid.tau[opt]

    f.hat <- x %*% delta.hat_1 + (q < tau.hat) * (x %*% delta.hat_2)
    f.alpha.known <- x %*% alpha_10 + (q < tau.hat) * (x %*% alpha_20)
    f.tau.known <- x %*% delta.hat_1 + (q < tau_0) * (x %*% delta.hat_2)
    check.L1 <- (t(f.alpha.known-f0) %*% (f.alpha.known-f0))/ (t(f.hat-f0) %*% (f.hat-f0))
    check.L2 <- (t(f.tau.known-f0) %*% (f.tau.known-f0))/ (t(f.hat-f0) %*% (f.hat-f0))
    
    rval <- list(model=m, est=c(s, tau.hat, delta.hat))

  return(rval)

}



simulate <- function(nrep, nobs, nx) {

	# Initialize the result matrices
	rval <- matrix(NA,nrep,nx*2+2) # lambda, tauhat, delta0(nx*1), delta1(nx*1)

    	for (i in 1:nrep) {
      		dat <- dgp(nobs=nobs, nx=nx)
      		attach(dat)
      		reg <- as.matrix(dat[,2:(ncol(dat)-1)])
      		dep <- y
      		thres.reg <- dat[,ncol(dat)]
      		detach(dat)
      		grid.tau <- seq(0.15,0.85, 0.01)
      		nonzero <- rep(TRUE,nx*2)

		#--------------------------
		# First, we calculate r_n to get lambda (the tuning parameter)
		#--------------------------
		t_0 <- grid.tau[1]
		ind_t0<-matrix(rep(thres.reg < t_0),nobs,nx)
		x_tau <- reg * ind_t0
		r_n <- min( diag( t(x_tau) %*% x_tau ) / diag(t(reg)%*%reg) )
		
		lambda <- A*sigma*sqrt(log(nx*3)/(nobs*r_n))


  		rval[i,] <- tlasso(reg, dep, thres.reg, s=lambda, grid.tau, nonzero)$est

		# Print out the result
		cat('# of simulations = ', i, '\n')
		cat('tauhat=',rval[i,2],'\n')
		cat('coef1=',rval[i,3:(nx+2)],'\n')
		cat('coef2=',rval[i,(nx+3):(nx*2+2)],'\n')
		cat('lambda=',rval[i,1],'\n')
		cat('\n')

            
    	} 

	

    	return(rval)
}

