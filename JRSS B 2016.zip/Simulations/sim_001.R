rm(list=ls())
library('lars')

# parameters
nobs=200  # The number of observations
nrep=400  # The number of replication
nx=50     # The dimension of X_i. We used the notation M for this in the paper
sigma=0.5 # Standard deviation of the error term
jump=1    # Is there threshold effects?
A=2.8	  # Tuning parameter for lambda	
true.par <- c(0.5, c(1,0,1,rep(0,nx-3)), jump*c(0,-1,1,rep(0,nx-3))) 



source("myfun.R")
start.time <- proc.time()[3]
fnum <- "001"
set.seed(as.integer(fnum))

result <- simulate(nrep=nrep, nobs=nobs, nx=nx)

# Print computation time & save the result    
runt <- proc.time()[3]-start.time
runt_h <- floor(runt/3600)
runt_m <- floor( (runt/3600 - runt_h) * 60 )
runt_s <- floor( (runt/60 - (runt_h*60) - runt_m) * 60 )
cat('\n',"runtime = ",runt_h,"h",runt_m,"m",runt_s,"s",'\n','\n')
cat('-----------------------------------------------------------','\n')

save.image(paste("sim_",fnum,".RData",sep=""))

dic<-getwd()

source("summary.R")




