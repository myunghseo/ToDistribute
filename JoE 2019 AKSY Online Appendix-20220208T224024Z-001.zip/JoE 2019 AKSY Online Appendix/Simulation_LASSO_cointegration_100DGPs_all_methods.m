%% Initialisation
clc; 
clear;
warning off;

myCluster=parcluster('local'); 
myCluster.NumWorkers=15; 
parpool(myCluster,15);

nx2=50;        % dimension of non-persistent predictor (p)
ndgp=100;       % number of DGPs considered here

filename=['AR2coeff_p=' num2str(nx2) '_ndgp=' num2str(ndgp) '.mat'];
load(filename);

s = RandStream.create('mrg32k3a','NumStreams',ndgp,'Seed',1438317,'CellOutput',true);

tic;

%% Preparation
nsim=1000;      % number of simulation
sizes=[ 100; 200; 400; 1000 ];  % number of observation
nsize=length(sizes);
npre=1000;      % number of pre-sample
nprd=1;         % forecasting horizon
nx1=4;          % number of persistent predictor
nvar=nx1+nx2;   % number of predictor

% coefficients
delta=[1; -0.5; 0; 0];      % cointegrating vector
alpha=[0; 0.3; 0; 0.2];     % loading
A1=alpha*delta'+eye(nx1);   % coefficient matrix for persistent predictors
cst=zeros(1,nx2);           % constant term in non-persistent predictors
c=0.15;                     % constant term in predictive regression

% initialise the storage
mse0=zeros(nsize,ndgp);     % MSE for OLS model
mser=zeros(nsize,ndgp);     % MSE for random walk
msep=zeros(nsize,ndgp);     % MSE for principal component
msee=zeros(nsize,ndgp);     % MSE for elastic net
msef=zeros(nsize,ndgp);     % MSE for forward chaining LASSO

msec=zeros(nsize,ndgp);     % MSE for constant model
msea=zeros(nsize,ndgp);     % MSE for AR(1) model
msem=zeros(nsize,ndgp);     % MSE for forecast combination
mse1=zeros(nsize,ndgp);     % MSE for min cv LASSO
mse2=zeros(nsize,ndgp);     % MSE for 1se cv LASSO


%% simulate the sample of size nobs
for ns=1:nsize
    
    nobs=sizes(ns);
    h=floor(0.1*nobs);      % evaluation window size for forward chaining LASSO
    
    %% loop over different DGP
    parfor dgp=1:ndgp
        
        RandStream.setGlobalStream(s{dgp});
        
        % coefficient for non-persistent predictors
        A2=reshape(rA1(:,dgp),nx2,nx2);
        A3=reshape(rA2(:,dgp),nx2,nx2);
        
        % draw coefficients in the predictive regression from U[-0.3,0.3]
        beta=0.6*rand(1,nvar)-0.3;
        beta(1:nx1)=0.3*delta;  % coefficients in the predictive regression
        beta(nx1+1:end)=beta(nx1+1:end).*randi([0,1],1,nx2);
        
        %% loop over 1000 simulation
        for sim=1:nsim
           
            % RandStream.setGlobalStream(s{100*(dgp-1)+sim});

            % error terms with no contemporaneous correlation
            et=randn(nobs+npre+nprd,nvar+1);
            y=zeros(size(et));
            % first observation
            y(1,:)=et(1,:);
            % second observation
            y(2,1)=c+y(1,2:end)*beta'+et(2,1);
            y(2,1+1:1+nx1)=y(1,1+1:1+nx1)*A1'+et(2,1+1:1+nx1);
            y(2,1+nx1+1:end)=cst+y(1,1+nx1+1:end)*A2'+et(2,1+nx1+1:end);
            
            for i=3:size(y,1)
                y(i,1)=c+y(i-1,2:end)*beta'+et(i,1);
                % cointegrated persistent variables
                y(i,1+1:1+nx1)=y(i-1,1+1:1+nx1)*A1'+et(i,1+1:1+nx1);
                % non-persistent variables
                y(i,1+nx1+1:end)=cst+y(i-1,1+nx1+1:end)*A2'+y(i-2,1+nx1+1:end)*A3'+et(i,1+nx1+1:end);
            end
        
            % estimation sample
            ys=y(npre+1:npre+nobs,1);
            xs=y(npre:npre+nobs-1,2:end);
            yslag=y(npre:npre+nobs-1,1);
        
            % forecast sample
            yf=y(npre+nobs+1:npre+nobs+nprd,1);
            xf=y(npre+nobs:npre+nobs+nprd-1,2:end);
        
        
            %% ----------- Simple Models ----------- %%
            % OLS regression -- kitchen sink model
            if nobs>nvar
                beta_hat0 =regress(ys, [ones(nobs,1) xs]);
                fetemp0=yf-[ones(length(yf),1) xf]*beta_hat0;
                mse0(ns,dgp)=mse0(ns,dgp)+fetemp0^2/nsim;
            end
            
            % random walk model
            fetempR=yf-ys(end);
            mser(ns,dgp)=mser(ns,dgp)+fetempR^2/nsim;
            
            % principal component with standardised variables
            xstd=xs(:,nx1+1:end)-mean(xs(:,nx1+1:end));
            xstd=xstd./repmat(std(xstd),nobs,1);
            xfstd=xf(:,nx1+1:end)-mean(xf(:,nx1+1:end));
            xfstd=xfstd./repmat(std(xfstd),length(yf),1);
            
            coeffs=pca(xstd);
            beta_hatps=regress(ys,[ones(nobs,1) xs(:,1:nx1) xstd*coeffs(:,1:4)]);
            fetempP=yf-[ones(length(yf),1) xf(:,1:nx1) xfstd*coeffs(:,1:4)]*beta_hatps;
            msep(ns,dgp)=msep(ns,dgp)+fetempP^2/nsim;
            
            
            %% ----------- LASSO model ----------- %%
            % elastic-net with mixing parameter = 0.5
            opts=struct('alpha',0.5);
            options=glmnetSet(opts);
            CrossVe = cvglmnet(xs, ys, [], options, [], nobs, [], 'true');
            cvind=find(CrossVe.glmnet_fit.lambda==CrossVe.lambda_min);     % min cv        
            beta_hatE=CrossVe.glmnet_fit.beta(:,cvind);
            alfa_hatE=CrossVe.glmnet_fit.a0(cvind);
            fetempE=yf-alfa_hatE-xf*beta_hatE;
            msee(ns,dgp)=msee(ns,dgp)+fetempE^2/nsim;

            % forward chaining
            % leave the last 3 observation to choose lambda
            [B,F1] = lasso(xs(1:nobs-h,:),ys(1:nobs-h,:),'NumLambda',100);
            nlam=length(F1.Intercept);
            err=repmat(ys(nobs-h+1:nobs,:),1,nlam)-repmat(F1.Intercept,h,1)-xs(nobs-h+1:nobs,:)*B;
            % find lambda that minimizes the forecast error
            [~,lamid]=min(sum(err.^2));
            lam=F1.Lambda(lamid);
            [beta_hatf,F2]=lasso(xs,ys,'Lambda',lam);
            alfa_hatf=F2.Intercept;
            fetempF=yf-alfa_hatf-xf*beta_hatf;
            msef(ns,dgp)=msef(ns,dgp)+fetempF^2/nsim;

            
            %% --------- comparison group --------- %%
            % Constant only -- historical average
            [alfa,~,~,~,statC]=regress(ys,ones(nobs,1));
            fetempC=yf-alfa;
            msec(ns,dgp)=msec(ns,dgp)+fetempC^2/nsim;

            % AR(1) model
            [rho,~,~,~,statA]=regress(ys,[ones(nobs,1) yslag]);
            fetempA=yf-[1 ys(end)]*rho;
            msea(ns,dgp)=msea(ns,dgp)+fetempA^2/nsim;

            % forecast combination
            ftempM=zeros(size(xs,2),1);
            for i=1:size(xs,2)
                btempM=regress(ys,[ones(nobs,1) xs(:,i)]);
                ftempM(i)=[ones(length(yf),1) xf(:,i)]*btempM;
            end
            fetempM=yf-mean(ftempM);
            msem(ns,dgp)=msem(ns,dgp)+fetempM^2/nsim;
            
            % other two LASSO models
            CrossVal = cvglmnet(xs,ys,[],[],[],nobs);
            cvindex1=find(CrossVal.glmnet_fit.lambda==CrossVal.lambda_min);     % min cv        
            beta_hat1=CrossVal.glmnet_fit.beta(:,cvindex1);
            alfa_hat1=CrossVal.glmnet_fit.a0(cvindex1);
            fetemp1=yf-alfa_hat1-xf*beta_hat1;
            mse1(ns,dgp)=mse1(ns,dgp)+fetemp1^2/nsim;
            
            [beta_hat2,F2]=lasso(xs,ys,'Lambda',0.1*log(nx2)/sqrt(nobs));         % fixed value of lambda
            alfa_hat2=F2.Intercept;
            fetemp2=yf-alfa_hat2-xf*beta_hat2;
            mse2(ns,dgp)=mse2(ns,dgp)+fetemp2^2/nsim;
            
        end
    end
end


%% display the results for forecasting accuracy
clc;
format long
disp('   ');
disp('One-step ahead mean squared prediction error');
disp('   ');
disp('        OLS all           random walk          principal          elastic net        forward LASSO');
disp([ mean(mse0,2) mean(mser,2) mean(msep,2) mean(msee,2) mean(msef,2) ]);
disp('      constant only        AR(1) model             comb             LASSO_min           LASSO_fixed');
disp([ mean(msec,2) mean(msea,2) mean(msem,2) mean(mse1,2) mean(mse2,2) ]);

filename2=['Simulation_Results_p=' num2str(nx2) '_ndgp=' num2str(ndgp) '_result_all.mat'];
save(filename2);


toc

